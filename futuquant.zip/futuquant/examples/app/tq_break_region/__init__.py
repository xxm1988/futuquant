# encoding: UTF-8

from __future__ import division
