
## 文件说明：
+ Windows 平台安装 MongoDB.url: vnpy 需要MongoDB支持，相关的帮助链接
+ CtaBacktesting: 回测范例，代码源于vnpy，作了简单的修改
+ CtaTrading: 实盘范例, 代码源于vnpy，作了简单的修改
+ vnTrader: 带UI的范例，代码源于vnpy，作了简单的修改



